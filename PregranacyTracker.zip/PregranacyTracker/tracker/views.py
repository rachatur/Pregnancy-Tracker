# tracker/views.py
import datetime
from urllib import request
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth.forms import AuthenticationForm
from .forms import PregnancyForm, WeightRecordForm
from .models import Appointment, Pregnancy, PregnancyPrescription, PregnancyTracker, WeightRecord
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import RegisterForm, LoginForm
from datetime import datetime, timedelta
from .models import Recovery, BabyCare, PostpartumCheckup
from django.templatetags.static import static
from tracker.models import Pregnancy 
from django.contrib.auth.models import User


def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Registration successful.')
            return redirect('login')
    else:
        form = RegisterForm()
    return render(request, 'tracker/register.html', {'form': form})

def login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(username=username, password=password)
            if user is not None:
                auth_login(request, user)
                return redirect('missingDate_form')  # Redirect to your desired page
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = LoginForm()
    return render(request, 'tracker/login.html', {'form': form})


# def missingDate_form(request):
#     if request.method == 'POST':
#         form = PregnancyForm(request.POST)
#         if form.is_valid():
#             pregnancy = form.save()
#             return redirect('result', pk=pregnancy.pk)
#     else:
#         form = PregnancyForm()
#     return render(request, 'tracker/missingDate_form.html', {'form': form})

# @login_required
# def missingDate_form(request):
#     if request.method == 'POST':
#         form = PregnancyForm(request.POST)
#         if form.is_valid():
#             pregnancy = form.save(commit=False)  # Create the instance but don't save it to the DB yet
#             pregnancy.owner = request.user  # Set the owner to the logged-in user
#             pregnancy.save()  # Now save it to the DB
#             # return redirect('pregnancy_info', pk=pregnancy.pk)
#             return redirect('result', pk=pregnancy.pk)  # Redirect to the result page
#     else:
#         form = PregnancyForm()
#     return render(request, 'tracker/missingDate_form.html', {'form': form})

# def result(request, pk):
#     # Get the pregnancy object
#     pregnancy = get_object_or_404(Pregnancy, pk=pk)
#     weeks_pregnant = pregnancy.weeks_pregnant()
    
#     if weeks_pregnant > 43:
#         status_message = 'Pregnancy has exceeded 43 weeks.'
#     else:
#         status_message = f'Pregnancy is {weeks_pregnant} weeks along.'

#     # Check menstrual cycle status
#     within_last_12_months = pregnancy.is_within_last_12_months()
#     beyond_12_months = pregnancy.is_beyond_12_months()

#     return render(request, 'tracker/missingDate_form.html', {
#         'pregnancy': pregnancy,
#         'weeks_pregnant': weeks_pregnant,
#         'status_message': status_message,
#         'within_last_12_months': within_last_12_months,
#         'beyond_12_months': beyond_12_months,
#     })

def logout(request):
    if request.method == 'POST':
        auth_logout(request)  # Log the user out
        return redirect('home')  # Redirect to the home page after logout
    else:
        template_name = 'tracker/logout.html'
        context = {}
        return render(request, template_name, context)
    # return redirect('home')

# def missingDate_form(request):
    # return render(request, 'tracker/missingDate_form.html')

def home(request):
    return render(request, 'tracker/home.html')

def profile(request):
    return render(request, 'tracker/profile.html')

def pregnancy(request):
    return render(request, 'tracker/pregnancy.html')

def my_doctor(request):
    return render(request, 'tracker/my_doctor.html')

# View for handling Recovery form submissions
def postpartum(request):
    if request.method == 'POST':
        # Handle Recovery form data
        if 'recovery-status' in request.POST:
            recovery_status = request.POST.get('recovery-status')
            recovery_notes = request.POST.get('recovery-notes', '')

            recovery = Recovery(
                recovery_status=recovery_status,
                recovery_notes=recovery_notes
            )
            recovery.save()

        # Handle Baby Care form data
        if 'baby-weight' in request.POST:
            baby_weight = request.POST.get('baby-weight')
            feeding_time = request.POST.get('feeding-time')
            sleep_duration = request.POST.get('sleep-duration')

            baby_care = BabyCare(
                baby_weight=baby_weight,
                feeding_time=feeding_time,
                sleep_duration=sleep_duration
            )
            baby_care.save()

        # Handle Postpartum Checkups form data
        if 'next-visit' in request.POST:
            next_visit = request.POST.get('next-visit')
            doctor_notes = request.POST.get('doctor-notes', '')

            checkup = PostpartumCheckup(
                next_visit=next_visit,
                doctor_notes=doctor_notes
            )
            checkup.save()

        return redirect('postpartum')  # Redirect after submission

    return render(request, 'tracker/postpartum.html')

def kegel_exercise(request):
    return render(request, 'tracker/kegel_exercise.html')

def settings(request):
    return render(request, 'tracker/settings.html')

def emergency_appointment(request):
    return render(request, 'tracker/emergency_appointment.html')

def week_by_week(request):
    weeks = [
        {"number": i, "text": f"{i} week{'s' if i > 1 else ''} pregnant", "link": f"/pregnancy/week-by-week/{i}-weeks-pregnant"}
        for i in range(1, 43)
    ]
    return render(request, 'tracker/week_by_week.html', {'weeks': weeks})

# def week_by_week(request):
#     return render(request, 'tracker/week_by_week.html')

def meal_recommendation(request):
    return render(request, 'tracker/meal_recommendation.html')

# def weight_tracker(request):
#     return render(request, 'tracker/weight_tracker.html')

def prescriptions(request):
    return render(request, 'tracker/prescriptions.html')

def reports(request):
    return render(request, 'tracker/reports.html')

def appointments(request):
    if request.method == 'POST':
        # Extract data directly from request.POST
        name = request.POST.get('name')
        profession = request.POST.get('profession')
        date = request.POST.get('date')
        time = request.POST.get('time')
        moms_weight = request.POST.get('moms_weight')
        bp = request.POST.get('bp')
        baby_heart_rate = request.POST.get('baby_heart_rate')
        notes = request.POST.get('notes')
        sync_to_calendar = request.POST.get('sync_to_calendar') == 'on'
        set_reminder = request.POST.get('set_reminder') == 'on'

        # Create and save the appointment instance directly
        Appointment.objects.create(
            name=name,
            profession=profession,
            date=date,
            time=time,
            moms_weight=moms_weight,
            bp=bp,
            baby_heart_rate=baby_heart_rate,
            notes=notes,
            sync_to_calendar=sync_to_calendar,
            set_reminder=set_reminder
        )

        return redirect('appointments')  # Redirect to prevent resubmission

    # Fetch all existing appointments to display them
    appointments = Appointment.objects.all()
    return render(request, 'tracker/appointments.html', {'appointments': appointments})

def card_list(request):
    return render(request, 'tracker/card_list.html')

# def calculate_weeks(lmp_date):
#     today = datetime.today().date()  # Use date() to get just the date part
#     weeks = (today - lmp_date).days // 7
#     return weeks

# def pregnancy_tracker_view(request):
#     # Fetch the user's pregnancies; this will return a queryset
#     pregnancies = Pregnancy.objects.filter(owner=request.user)

#     if pregnancies.exists():  # Check if there are any pregnancies
#         pregnancy = pregnancies.first()  # Retrieve the first pregnancy
#         lmp_date = pregnancy.last_menstrual_period  # Get the last menstrual period date

#         # Calculate the current week based on LMP
#         current_week = calculate_weeks(lmp_date)

#         # Prepare week data for the frontend
#         weeks = [{"number": week, "text": f"Details for week {week}"} for week in range(current_week + 1)]
        
#         # Return the LMP date and the weeks information
#         return render(request, 'tracker/week_view.html', {'lmp_date': lmp_date, 'weeks': weeks, 'pregnancy': pregnancy})
#     else:
#         # Handle the case where there are no pregnancies
#         return render(request, 'tracker/week_view.html', {'pregnancy': None})


def delete_weight_record(request, record_id):
    if request.method == "POST":
        try:
            record = WeightRecord.objects.get(id=record_id)
            record.delete()
            return JsonResponse({'success': True})
        except WeightRecord.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Record not found'}, status=404)

def weight_tracker(request):
    if request.method == 'POST':
        form = WeightRecordForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('weight_tracker')  # Redirect after successful submission
    else:
        form = WeightRecordForm()  # Initialize an empty form for GET requests

    records = WeightRecord.objects.all()  # Fetch all weight records
    return render(request, 'tracker/weight_tracker.html', {'form': form, 'records': records})

def get_weight_data(request):
    records = WeightRecord.objects.all().values('date_current_weight', 'current_weight', 'last_period_weight')
    return JsonResponse(list(records), safe=False)

def prescriptions(request):
    if request.method == 'POST':
        # Capture form data from POST request
        patient_name = request.POST.get('patient_name')
        patient_age = request.POST.get('patient_age')
        due_date = request.POST.get('due_date')
        medications = request.POST.get('medications')
        notes = request.POST.get('notes')
        
        # Save the data to the database (assuming a PregnancyPrescription model)
        prescription = PregnancyPrescription(
            patient_name=patient_name,
            patient_age=patient_age,
            due_date=due_date,
            medications=medications,
            notes=notes
        )
        prescription.save()
        
        return redirect('prescription_success')
    
    return render(request, 'tracker/prescriptions.html')

# View to handle the success page
def prescription_success(request):
    return render(request, 'tracker/success.html')


from django.shortcuts import render, redirect
from django.http import JsonResponse
from datetime import datetime
from .models import Pregnancy
from .forms import PregnancyForm

def missingDate_form(request):
    if request.method == 'POST':
        form = PregnancyForm(request.POST)
        week_image = None
        if form.is_valid():
            # Check if the user already has a Pregnancy record with a missing_date
            existing_pregnancy = Pregnancy.objects.filter(owner=request.user, missing_date__isnull=False).first()
            if existing_pregnancy:
                return JsonResponse({"error": "Missing date has already been entered and cannot be re-entered."}, status=400)
            
            # Calculate the week difference
            last_date = form.cleaned_data['last_menstrual_period']
            current_date = datetime.now().date()  # Get today's date
            week_difference = (current_date - last_date).days // 7

            # Prepare the Pregnancy instance
            pregnancy = form.save(commit=False)
            pregnancy.owner = request.user
            pregnancy.current_week = week_difference  # Set the current week
            pregnancy.due_date = pregnancy.calculate_due_date()  # Calculate and set the due date
            try:
                week_image = static(f'img/week_infoImg/week_{week_difference}.jpg')  # Adjust the path if necessary
            except Exception as e:
                # Handle the case where the image might not be found or another error occurs
                print(f"Error loading image for week {week_difference}: {e}")
            pregnancy.week_image = week_image
            pregnancy.save()

            return redirect('result', pk=pregnancy.pk)
    else:
        form = PregnancyForm()

    return render(request, 'tracker/missingDate_form.html', {'form': form})


def result(request, pk):
    pregnancy = get_object_or_404(Pregnancy, pk=pk)
    weeks_pregnant = pregnancy.weeks_pregnant()
    
    # Save the updated week to ensure consistency across views
    pregnancy.current_week = weeks_pregnant
    pregnancy.save()
    
    status_message = 'Pregnancy has exceeded 43 weeks.' if weeks_pregnant > 43 else f'Pregnancy is {weeks_pregnant} weeks along.'

    within_last_12_months = pregnancy.is_within_last_12_months()
    beyond_12_months = pregnancy.is_beyond_12_months()

    return render(request, 'tracker/missingDate_form.html', {
        'pregnancy': pregnancy,
        'weeks_pregnant': weeks_pregnant,
        'status_message': status_message,
        'within_last_12_months': within_last_12_months,
        'beyond_12_months': beyond_12_months,
    })

from django.shortcuts import render
from .models import Pregnancy

# @login_required
# def pregnancy_tracker(request):
#     # Fetch pregnancy details for the authenticated user
#     # pregnancy = Pregnancy.objects.get(id=232)
#     pregnancy = Pregnancy.objects.filter(owner=request.user).first()
#     week_image = None  # Initialize week_image with a default value

#     # Default values if no pregnancy data is found
#     if pregnancy:
#         weeks_pregnant = pregnancy.current_week or pregnancy.weeks_pregnant()
#         trimester = pregnancy.trimester()
#         days_left = pregnancy.days_left()
#         baby_length = pregnancy.baby_length()
#         baby_weight = pregnancy.baby_weight()
#         baby_size_comparison = pregnancy.baby_size_comparison()

#         if request.method == "POST":
#             # Update the week based on POST request from the slider
#             weeks = int(request.POST.get('week', weeks_pregnant))
#             pregnancy.current_week = weeks
#             try:
#                 week_image = static(f'img/week_infoImg/week_{weeks_pregnant}.jpg')  # Adjust the path if necessary
#             except Exception as e:
#                 # Handle the case where the image might not be found or another error occurs
#                 print(f"Error loading image for week {weeks_pregnant}: {e}")
#             pregnancy.week_image = week_image
            

#             if week_image:
#                 print('week image')
#                 print(week_image)
#                 pregnancy.save()
#             else:
#                 print('Can\'t fetch week image')

#             # Recalculate the trimester, days left, etc. after saving the new week
#             trimester = pregnancy.trimester()
#             days_left = pregnancy.days_left()
#             baby_length = pregnancy.baby_length()
#             baby_weight = pregnancy.baby_weight()
#             baby_size_comparison = pregnancy.baby_size_comparison()

#             # Image for the current week (you can store images in a static directory)
            
#             # Get the selected week from the request if available (for slider)
#             selected_week = int(request.GET.get('week', weeks_pregnant))
#             print('week image',week_image)
#         context = {
#             'weeks': pregnancy.current_week,
#             'weeks_pregnant': pregnancy.current_week,
#             'trimester': trimester,
#             'days_left': days_left,
#             'baby_length': baby_length,
#             'baby_weight': baby_weight,
#             'baby_size_comparison': baby_size_comparison,
#             'pregnancy_info':week_image
#         }
#     else:
#         # Fallback context if no pregnancy data is found
#         context = {
#             'weeks': 0,
#             'weeks_pregnant': 0,
#             'trimester': 'Unknown',
#             'days_left': 0,
#             'baby_length': 0,
#             'baby_weight': 0,
#             'baby_size_comparison': 'Unknown',
#             'pregnancy_info': {f'{week_image}': ''}
#         }

#     return render(request, 'tracker/week_by_week.html', context)


@login_required
def pregnancy_tracker(request):
    # Fetch pregnancy details for the authenticated user
    pregnancy = Pregnancy.objects.filter(owner=request.user).first()
    week_image = None  # Initialize week_image with a default value

    # Default values if no pregnancy data is found
    if pregnancy:
        weeks_pregnant = pregnancy.current_week or pregnancy.weeks_pregnant()
        trimester = pregnancy.trimester()
        days_left = pregnancy.days_left()
        baby_length = pregnancy.baby_length()
        baby_weight = pregnancy.baby_weight()
        baby_size_comparison = pregnancy.baby_size_comparison()

        if request.method == "POST":
            # Update the week based on POST request from the slider
            weeks = int(request.POST.get('week', weeks_pregnant))
            pregnancy.current_week = weeks

            # Default or fallback image
            try:
                # Attempt to generate the path for the current week's image
                week_image_path = f'img/week_infoImg/week_{weeks}.jpg'
                week_image = static(week_image_path)  # Generate the static URL for the week image
                pregnancy.week_image = week_image
            except Exception as e:
                # Handle the case where the image might not be found or another error occurs
                print(f"Error loading image for week {weeks}: {e}")
                # Optionally set a default fallback image if the specific image isn't found
                week_image = static('img/week_infoImg/week_default.jpg')
                pregnancy.week_image = week_image

            pregnancy.save()

            # Recalculate the trimester, days left, etc. after saving the new week
            trimester = pregnancy.trimester()
            days_left = pregnancy.days_left()
            baby_length = pregnancy.baby_length()
            baby_weight = pregnancy.baby_weight()
            baby_size_comparison = pregnancy.baby_size_comparison()

        context = {
            'weeks': pregnancy.current_week,
            'weeks_pregnant': pregnancy.current_week,
            'trimester': trimester,
            'days_left': days_left,
            'baby_length': baby_length,
            'baby_weight': baby_weight,
            'baby_size_comparison': baby_size_comparison,
            'pregnancy_info': week_image  # Make sure week_image is set here
        }
    else:
        # Fallback context if no pregnancy data is found
        context = {
            'weeks': 0,
            'weeks_pregnant': 0,
            'trimester': 'Unknown',
            'days_left': 0,
            'baby_length': 0,
            'baby_weight': 0,
            'baby_size_comparison': 'Unknown',
            'pregnancy_info': ''  # Handle the case where no pregnancy data exists
        }

    return render(request, 'tracker/week_by_week.html', context)



from .models import Meal

def meal_recommendation(request):
    # Fetch meals from the database
    meals = Meal.objects.all().order_by('category')
    return render(request, 'tracker/meal_recommendation.html', {'meals': meals})





# from django.shortcuts import render, get_object_or_404, redirect
# from .models import Doctor, Patient, RegularAppointment, EmergencyAppointment
# from django.http import HttpResponseBadRequest

# # View to show the doctor's profile and related patient info
# def child_growth(request, doctor_id):
#     # Get the doctor object
#     doctor = get_object_or_404(Doctor, id=doctor_id)

#     # Fetch the first associated patient (adjust logic if needed)
#     patient = Patient.objects.filter(doctor=doctor).first()

#     # Check if a patient is found, else handle it (optional error handling)
#     if not patient:
#         return HttpResponseBadRequest("No patient found for this doctor")

#     # Fetch available appointment slots (example logic, adjust to your needs)
#     available_slots = ['9:00 AM', '11:00 AM', '1:00 PM', '3:00 PM']

#     # Render the appropriate template
#     return render(request, 'tracker/child_growth.html', {
#         'doctor': doctor,
#         'patient': patient,
#         'available_slots': available_slots
#     })

# # View to handle booking a regular appointment (without forms.py)
# def book_appointment(request, doctor_id):
#     # Get the doctor object
#     doctor = get_object_or_404(Doctor, id=doctor_id)

#     # Fetch the first associated patient (adjust logic if needed)
#     patient = Patient.objects.filter(doctor=doctor).first()

#     # Check if a patient exists, else return an error response
#     if not patient:
#         return HttpResponseBadRequest("No patient found for this doctor")

#     if request.method == 'POST':
#         # Retrieve data from POST request
#         appointment_date = request.POST.get('appointment_date')
#         appointment_time = request.POST.get('appointment_time')

#         # Check if both date and time are provided
#         if appointment_date and appointment_time:
#             # Create and save the RegularAppointment
#             appointment = RegularAppointment(
#                 doctor=doctor,
#                 patient=patient,
#                 appointment_date=appointment_date,
#                 appointment_time=appointment_time
#             )
#             appointment.save()
#             # Redirect back to the doctor's profile page after successful booking
#             return redirect('doctor_profile', doctor_id=doctor.id)
#         else:
#             # Handle invalid form data
#             return HttpResponseBadRequest("Invalid form data")

#     # Render the page again if the method is GET
#     return render(request, 'tracker/doctor_profile.html', {
#         'doctor': doctor,
#         'patient': patient
#     })

# # View to handle booking an emergency appointment (without forms.py)
# def book_emergency_appointment(request, doctor_id):
#     # Get the doctor object
#     doctor = get_object_or_404(Doctor, id=doctor_id)

#     # Fetch the first associated patient (adjust logic if needed)
#     patient = Patient.objects.filter(doctor=doctor).first()

#     # Check if a patient exists, else return an error response
#     if not patient:
#         return HttpResponseBadRequest("No patient found for this doctor")

#     if request.method == 'POST':
#         # Retrieve data from POST request
#         emergency_date = request.POST.get('emergency_date')
#         emergency_time = request.POST.get('emergency_time')
#         emergency_type = request.POST.get('emergency_type')

#         # Check if all required data is provided
#         if emergency_date and emergency_time and emergency_type:
#             # Create and save the EmergencyAppointment
#             emergency_appointment = EmergencyAppointment(
#                 doctor=doctor,
#                 patient=patient,
#                 emergency_date=emergency_date,
#                 emergency_time=emergency_time,
#                 emergency_type=emergency_type
#             )
#             emergency_appointment.save()
#             # Redirect back to the doctor's profile page after successful booking
#             return redirect('doctor_profile', doctor_id=doctor.id)
#         else:
#             # Handle invalid form data
#             return HttpResponseBadRequest("Invalid form data")

#     # Render the page again if the method is GET
#     return render(request, 'tracker/child_growth.html', {
#         'doctor': doctor,
#         'patient': patient
#     })

