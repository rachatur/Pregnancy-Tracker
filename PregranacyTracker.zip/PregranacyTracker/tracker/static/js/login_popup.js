// login_popup.js
document.addEventListener("DOMContentLoaded", function() {
    const loginLink = document.getElementById("loginLink");
    const popup = document.getElementById("loginPopup");

    if (loginLink) {
        loginLink.addEventListener("click", function(event) {
            event.preventDefault();
            popup.style.display = "block";
        });
    }

    window.closePopup = function() {
        popup.style.display = "none";
    }
});
