# tracker/models.py
import datetime
from django.db import models
from django.utils import timezone
from datetime import timedelta
from django.contrib.auth.models import User

class Pregnancy(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    last_menstrual_period = models.DateField()
    due_date = models.DateField(blank=True, null=True)
    current_week = models.IntegerField(blank=True, null=True)  # Add this field to store weeks
    missing_date = models.DateField(null=True, blank=True)
    week_image = models.ImageField(upload_to='static/img/week_infoImg/', default='img/week_infoImg/download(1).jpg')
    week_number = models.IntegerField(default=0)  # Set a default value for existing rows

    class Meta:
        # Unique constraint ensures that each user can only have one pregnancy record
        constraints = [
            models.UniqueConstraint(fields=['owner'], name='unique_pregnancy_per_user')
        ]

    def __str__(self):
        return f"Week {self.week_number}"

    def __str__(self):
        return f"Pregnancy Week {self.current_week} for {self.owner.username}"
    
    def calculate_due_date(self):
        """Calculate the due date based on the last menstrual period.uihviuviy867438936577869 sanket123"""
        if self.last_menstrual_period:
            return self.last_menstrual_period + timedelta(weeks=40)
        return None
    
    def save(self, *args, **kwargs):
        """Save the pregnancy instance and calculate due date if not provided."""
        if not self.due_date:
            self.due_date = self.calculate_due_date()
        super().save(*args, **kwargs)
    
    def weeks_pregnant(self):
        """Calculate the current pregnancy week based on the last menstrual period."""
        if self.last_menstrual_period:
            current_date = datetime.date.today()
            week_difference = (current_date - self.last_menstrual_period).days // 7
            return week_difference
        return None

    def is_within_last_12_months(self):
        """Check if the last menstrual period is within the last 12 months."""
        twelve_months_ago = timezone.now().date() - timedelta(days=365)
        return self.last_menstrual_period >= twelve_months_ago

    def is_beyond_12_months(self):
        """Check if the last menstrual period is beyond 12 months."""
        return not self.is_within_last_12_months()

    def __str__(self):
        return f"Pregnancy: Last Period Date - {self.last_menstrual_period}, Pregnancy - Week {self.current_week}"
    

    def trimester(self):
        """Returns the current trimester based on the week"""
        if self.current_week <= 12:
            return "1st"
        elif self.current_week <= 28:
            return "2nd"
        else:
            return "3rd"
    
    def days_left(self):
        """Calculates the number of days left until the due date"""
        from datetime import date
        days_left = (self.due_date - date.today()).days
        return days_left
    
    def baby_size_comparison(self):
        """Returns a comparison for the baby's size (e.g., a fruit or vegetable)"""

        # Define the ranges with associated size descriptions
        size_ranges = {
            range(1, 4): "Apple seed",
            range(4, 8): "Lime",
            range(8, 12): "Peach",
            range(12, 16): "Plum",
            range(16, 20): "Avocado",
            range(20, 24): "Banana",
            range(24, 28): "Papaya",
            range(28, 32): "Cucumber",
            range(32, 36): "Squash",
            range(36, 40): "Cantaloupe",
            range(40, 41): "Watermelon"
        }

        # Loop through each range and return the matching size comparison
        for week_range, size in size_ranges.items():
            if self.current_week in week_range:
                return size

        # Default value if the week doesn't match any range
        return "Fruit placeholder"

    
    def baby_length(self):
        """Returns the baby's length in cm based on the current week."""
    # Define length data for each range of weeks
        length_data = {
            range(1, 4): 0.1,
            range(4, 8): 2.5,
            range(8, 12): 4.5,
            range(12, 16): 6,
            range(16, 20): 10,
            range(20, 24): 16,
            range(24, 28): 21,
            range(28, 32): 25,
            range(32, 36): 30,
            range(36, 40): 35,
            range(40, 41): 40
        }

        # Check each range to find where the current week falls
        for week_range, length in length_data.items():
            if self.current_week in week_range:
                return length
        
        # Default return value if no range is matched
        return 0
    


    def baby_weight(self):
        """Returns the baby's weight in grams based on the current week"""
    # Example: Returns approximate weight for weeks
        weight_data = {
            range(1, 4): 0.02,
            range(4, 8): 0.5,
            range(8, 12): 1.5,
            range(12, 16): 4,
            range(16, 20): 10,
            range(20, 24): 25,
            range(24, 28): 60,
            range(28, 32): 110,
            range(32, 36): 200,
            range(36, 40): 300,
            range(40, 41): 350
        }
    
        # Iterate through the ranges and check if the current_week falls within any range
        for week_range, weight in weight_data.items():
            if self.current_week in week_range:
                return weight

        # Default return value if no range is matched
        return 0





class MenstrualCycle(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    last_period_date = models.DateField()

    def is_within_last_12_months(self):
        """Check if the last period date is within the last 12 months."""
        twelve_months_ago = timezone.now().date() - timedelta(days=365)
        return self.last_period_date >= twelve_months_ago

    def is_beyond_12_months(self):
        """Check if the last period date is beyond 12 months."""
        return not self.is_within_last_12_months()

    def __str__(self):
        return f"{self.user.username}: Last Period Date - {self.last_period_date}"
    
class WeightRecord(models.Model):
    date_last_period = models.DateField()
    last_period_weight = models.FloatField()
    date_current_weight = models.DateField()
    current_weight = models.FloatField()

    def change(self):
        """Calculate the change in weight."""
        return self.current_weight - self.last_period_weight

    def __str__(self):
        """String representation of the WeightRecord."""
        return f"Weight on {self.date_current_weight}: {self.current_weight} kg"
    
class PregnancyPrescription(models.Model):
    patient_name = models.CharField(max_length=100)
    patient_age = models.PositiveIntegerField()
    due_date = models.DateTimeField()
    medications = models.TextField()
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.patient_name} - {self.due_date}"


class Appointment(models.Model):
    name = models.CharField(max_length=255)
    profession = models.CharField(max_length=255)
    date = models.DateField()
    time = models.TimeField()
    moms_weight = models.DecimalField(max_digits=5, decimal_places=2)
    bp = models.CharField(max_length=50)
    baby_heart_rate = models.IntegerField()
    notes = models.TextField(blank=True, null=True)
    sync_to_calendar = models.BooleanField(default=False)
    set_reminder = models.BooleanField(default=False)

    def __str__(self):
        return f'{self.name} - {self.profession} on {self.date} at {self.time}'
    

class Recovery(models.Model):
    STATUS_NORMAL = 'normal'
    STATUS_MODERATE = 'moderate_pain'
    STATUS_SEVERE = 'severe_pain'

    STATUS_CHOICES = [
        (STATUS_NORMAL, 'Normal'),
        (STATUS_MODERATE, 'Moderate Pain'),
        (STATUS_SEVERE, 'Severe Pain'),
    ]

    recovery_status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_NORMAL,
        verbose_name="Recovery Status"
    )
    recovery_notes = models.TextField(
        blank=True, 
        null=True, 
        verbose_name="Additional Notes",
        help_text="Provide additional details on recovery progress."
    )
    date = models.DateTimeField(
        auto_now_add=True, 
        verbose_name="Recorded Date"
    )

    def __str__(self):
        return f"Recovery: {self.recovery_status} on {self.date}"


class BabyCare(models.Model):
    baby_weight = models.FloatField(
        verbose_name="Baby's Weight (kg)",
        help_text="Enter the baby's weight in kilograms."
    )
    feeding_time = models.TimeField(
        verbose_name="Last Feeding Time",
        help_text="Record the last feeding time of the baby."
    )
    sleep_duration = models.FloatField(
        verbose_name="Sleep Duration (hours)",
        help_text="How long the baby slept in hours."
    )
    date = models.DateTimeField(
        auto_now_add=True, 
        verbose_name="Recorded Date"
    )

    def __str__(self):
        return f"Baby Care Entry on {self.date}"


class PostpartumCheckup(models.Model):
    next_visit = models.DateField(
        verbose_name="Next Checkup Date",
        help_text="The scheduled date for the next postpartum checkup."
    )
    doctor_notes = models.TextField(
        blank=True, 
        null=True, 
        verbose_name="Doctor's Notes",
        help_text="Instructions or observations from the doctor."
    )
    date = models.DateTimeField(
        auto_now_add=True, 
        verbose_name="Recorded Date"
    )

    def __str__(self):
        return f"Checkup scheduled for {self.next_visit}"




from django.db import models

class PregnancyTracker(models.Model):
    # Store the pregnancy data like the current week, trimester, and due date
    current_week = models.PositiveIntegerField()
    due_date = models.DateField()
    
    def __str__(self):
        return f"Pregnancy - Week {self.current_week}"

    def trimester(self):
        """Returns the current trimester based on the week"""
        if self.current_week <= 12:
            return "1st"
        elif self.current_week <= 28:
            return "2nd"
        else:
            return "3rd"
    
    def days_left(self):
        """Calculates the number of days left until the due date"""
        from datetime import date
        days_left = (self.due_date - date.today()).days
        return days_left
    
    def baby_size_comparison(self):
        """Returns a comparison for the baby's size (e.g., a fruit or vegetable)"""
        size_comparisons = {
            1: "Apple seed", 4: "Lime", 8: "Peach", 12: "Plum", 16: "Avocado",
            20: "Banana", 24: "Papaya", 28: "Cucumber", 32: "Squash", 36: "Cantaloupe",
            40: "Watermelon"
        }
        return size_comparisons.get(self.current_week, "Fruit placeholder")
    
    def baby_length(self):
        """Returns the baby's length in cm based on the current week"""
        # Example: Returns approximate length for weeks
        length_data = {
            1: 0.1, 4: 2.5, 8: 4.5, 12: 6, 16: 10, 20: 16, 24: 21, 28: 25, 32: 30, 36: 35, 40: 40
        }
        return length_data.get(self.current_week, 0)

    def baby_weight(self):
        """Returns the baby's weight in grams based on the current week"""
        # Example: Returns approximate weight for weeks
        weight_data = {
            1: 0.02, 4: 0.5, 8: 1.5, 12: 4, 16: 10, 20: 25, 24: 60, 28: 110, 32: 200, 36: 300, 40: 350
        }
        return weight_data.get(self.current_week, 0)
    





class Meal(models.Model):
    CATEGORY_CHOICES = [
        ('breakfast', 'Breakfast'),
        ('snack', 'Snack'),
        ('lunch', 'Lunch'),
        ('dinner', 'Dinner'),
    ]

    name = models.CharField(max_length=255)
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    prep_time = models.IntegerField(help_text="Preparation time in minutes")
    cook_time = models.IntegerField(help_text="Cooking time in minutes")
    image = models.ImageField(upload_to='meal_images/', null=True, blank=True)

    def __str__(self):
        return self.name
    



from django.db import models

# Model to represent the doctor
class Doctor(models.Model):
    name = models.CharField(max_length=100)
    specialty = models.CharField(max_length=100)
    qualifications = models.TextField()
    experience = models.IntegerField()
    contact_info = models.CharField(max_length=255)

    def __str__(self):
        return self.name

# Model to represent the patient
class Patient(models.Model):
    name = models.CharField(max_length=100)
    pregnancy_week = models.IntegerField()
    contact_info = models.CharField(max_length=255)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE, related_name='patients')

    def __str__(self):
        return self.name

# Model to represent a regular appointment (renamed from Appointment)
class RegularAppointment(models.Model):
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE, related_name='regular_appointments')
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='regular_appointments')
    appointment_date = models.DateField()
    appointment_time = models.TimeField()

    def __str__(self):
        return f"Appointment with {self.doctor.name} for {self.patient.name}"

# Model to represent an emergency appointment
class EmergencyAppointment(models.Model):
    EMERGENCY_TYPES = [
        ('normal', 'Normal'),
        ('critical', 'Critical'),
    ]
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE, related_name='emergency_appointments')
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='emergency_appointments')
    emergency_type = models.CharField(max_length=10, choices=EMERGENCY_TYPES)
    emergency_date = models.DateField()
    emergency_time = models.TimeField()

    def __str__(self):
        return f"{self.emergency_type.capitalize()} emergency with {self.doctor.name}"







