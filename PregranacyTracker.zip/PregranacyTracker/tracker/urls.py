# tracker/urls.py
from django.urls import path

from PregranacyTracker import settings
from . import views
from django.conf.urls.static import static


urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('', views.home, name='home'),
    path('result/<int:pk>/', views.result, name='result'),
    # path('profile/' views.profile, name='profile'),

    path('missingDate_form', views.missingDate_form, name='missingDate_form'),
    # path('status/', views.status, name='status'),
    # path('record/', views.record, name='record'),
    path('pregnancy/', views.pregnancy, name='pregnancy'),
    path('my_doctor/', views.my_doctor, name='my_doctor'),  # Include doctor_id
    # path('my-doctor/<int:doctor_id>/', views.my_doctor, name='my_doctor'),
    # path('doctor/<int:doctor_id>/', views.child_growth, name='doctor_profile'),
    # path('doctor/<int:doctor_id>/book_appointment/', views.book_appointment, name='book_appointment'),
    # path('doctor/<int:doctor_id>/book_emergency_appointment/', views.book_emergency_appointment, name='book_emergency_appointment'),

    path('postpartum/', views.postpartum, name='postpartum'),

    path('kegel-exercise/', views.kegel_exercise, name='kegel_exercise'), # type: ignore
    path('settings/', views.settings, name='settings'),
    path('emergency-appointment/', views.emergency_appointment, name='emergency_appointment'), # type: ignore

    path('pregnancy/week-by-week/', views.pregnancy_tracker, name='week_by_week'),
    path('pregnancy/meal-recommendation/', views.meal_recommendation, name='meal_recommendation'),
    path('pregnancy/weight-tracker/', views.weight_tracker, name='weight_tracker'),

    path('pregnancy/prescriptions/', views.prescriptions, name='prescriptions'),
    path('success/', views.prescription_success, name='prescription_success'),

    path('pregnancy/reports/', views.reports, name='reports'),
    path('pregnancy/appointments/', views.appointments, name='appointments'),
    path('card_list/', views.card_list, name='card_list'),

    # path('add_weight/', views.add_weight, name='add_weight'),
    path('get_weight_data/', views.get_weight_data, name='get_weight_data'),
    path('delete_weight/<int:record_id>/', views.delete_weight_record, name='delete_weight'),

    # path('week_view/', views.pregnancy_tracker_view, name='week_view'),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
