# tracker/forms.py
from django import forms
from .models import MenstrualCycle, Pregnancy, PregnancyPrescription
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
from .models import WeightRecord



class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)

# class LoginForm(AuthenticationForm):
#     username = forms.CharField(label='Username', widget=forms.TextInput(attrs={'class': 'form-control'}))
#     password = forms.CharField(label='Password', widget=forms.PasswordInput(attrs={'class': 'form-control'}))

class PregnancyForm(forms.ModelForm):
    class Meta:
        model = Pregnancy
        fields = ['last_menstrual_period']
        widgets = {
            'last_menstrual_period': forms.DateInput(attrs={'type': 'date'})
        }

class MenstrualCycleForm(forms.ModelForm):
    class Meta:
        model = MenstrualCycle
        fields = ['last_period_date']

class WeightRecordForm(forms.ModelForm):
    class Meta:
        model = WeightRecord
        fields = ['date_last_period', 'last_period_weight', 'date_current_weight', 'current_weight']
        
class PrescriptionForm(forms.ModelForm):
    class Meta:
        model = PregnancyPrescription
        fields = ['patient_name', 'patient_age', 'due_date', 'medications', 'notes']
        widgets = {
            'due_date': forms.DateTimeInput(attrs={
                'type': 'datetime-local',  # This will create a datetime picker
                'class': 'form-control',
            }),
        }
